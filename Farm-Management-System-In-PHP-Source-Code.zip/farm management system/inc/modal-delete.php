<div id="_remove" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">

	  <div class="modal-content">
	     <div class="modal-header">
		   <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
		   <h3 class="modal-title">Remove From Quarantine List ?</h3>
	    </div>

	   <div class="modal-body">
		  <div class="alert alert-danger">
		     <p>Are you sure you want to remove pig from quarantine list?.</p>
		  </div>
       </div>
	   <div class="modal-footer">
		  <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="fa fa-times"></i> Close</button>
		 <button name="remove" class="btn btn-danger"><i class="fa fa-check"></i> Yes</button>
	   </div>
    </div>
  </div>
</div>

<div id="_removed" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">

	  <div class="modal-content">
	     <div class="modal-header">
		   <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
		   <h3 class="modal-title">Delete breed?</h3>
	    </div>

	   <div class="modal-body">
		  <div class="alert alert-danger">
		     <p>Are you sure you want to remove breed from list?.</p>
		  </div>
       </div>
	   <div class="modal-footer">
		  <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="fa fa-times"></i> Close</button>
		 <button name="removed" class="btn btn-danger"><i class="fa fa-check"></i> Yes</button>
	   </div>
    </div>
  </div>
</div>

