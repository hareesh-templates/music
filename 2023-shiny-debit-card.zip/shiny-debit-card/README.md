# Shiny Debit Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/GROreja](https://codepen.io/jkantner/pen/GROreja).

Plastic currency drawn with various CSS effects.